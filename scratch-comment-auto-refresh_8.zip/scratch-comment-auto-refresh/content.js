/**
 * Scratch コメント自動更新 - content script
 *
 * 対応ページ:
 *  - プロジェクトページ: https://scratch.mit.edu/projects/<project_id>/
 *  - スタジオページ:     https://scratch.mit.edu/studios/<studio_id>/ (コメントタブ含む)
 *
 * 重要な設計方針(2回の失敗から得た知見):
 *
 *  [失敗1] 独立フローティングパネルに新着コメントを表示する方式
 *   → 「ページのその場所に反映してほしい」という要望に合わなかった。
 *
 *  [失敗2] .comments-list の「直前」(外側、兄弟要素)に専用コンテナを
 *   挿入する方式
 *   → Scratchのページはコメント欄とサイドバー情報(タイトル・フォロー
 *     ボタン・サムネイル等)を含む親要素がCSS Grid/Flexで組まれており、
 *     その親の直接の子として要素を1つ増やすと、列の並びや幅の計算が
 *     ズレて全体のレイアウトが圧縮・崩れてしまった。
 *
 *  [現在の方式] .comments-list の「内側の先頭」に直接カードを挿入する
 *   → comments-list自身は中の各コメントを縦に並べるための単純な
 *     flexコンテナであり、その内側に同じ見た目のカードを1つ増やしても
 *     ページ全体のレイアウト(列の数や配置)には影響しない。
 *   → Reactがこの範囲を再描画すると挿入したカードが消える可能性はある
 *     が、Scratchはコメント欄を自動で再フェッチしないため通常は起きない。
 *     念のため、短い間隔で「カードが消えていないか」を確認し、消えて
 *     いたら自動で再挿入する自己修復処理を入れている。
 *
 * 仕組み:
 *  1. 公式 API (api.scratch.mit.edu) からコメント一覧を定期的に取得する
 *  2. 直前に取得したコメントID集合と比較し、新着コメントを検出する
 *  3. 新着があれば、コメント欄の先頭にカードを直接挿入する
 *  4. 1秒ごとに「挿入したカードがまだ存在するか」を確認し、消えていたら
 *     再挿入する(自己修復)
 *  5. ポップアップから ON/OFF・更新間隔を変更できる(chrome.storage.sync で共有)
 */

(() => {
  "use strict";

  const DEFAULT_SETTINGS = {
    enabled: true,
    intervalSec: 20, // 何秒ごとにAPIをチェックするか
  };

  const INLINE_CARD_CLASS = "sc-auto-refresh-comment-card";
  const MAX_INLINE_ITEMS = 30;
  const WATCH_INTERVAL_MS = 1000;

  // Scratchの実装(scratch-www)で使われている実際のコメント一覧のクラス名。
  // プロジェクトページ・スタジオページで共通のコンポーネントが使われている。
  const COMMENT_LIST_SELECTORS = [
    ".comments-list",
    "[class*='comments-list']",
  ];

  const STATE = {
    settings: { ...DEFAULT_SETTINGS },
    knownCommentIds: new Set(),
    insertedComments: [], // 画面に表示中の新着コメント(新しい順)
    timerId: null,
    pageInfo: null, // { type: 'project'|'studio', id, username? }
    initialized: false,
    lastError: null,
    commentsListFound: false,
    lastCheckedAt: null,
    lastFetchCount: null,
  };

  // ---------- ユーティリティ ----------

  function log(...args) {
    console.log("[Scratchコメント自動更新]", ...args);
  }

  function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str ?? "";
    return div.innerHTML;
  }

  function formatDateTime(iso) {
    try {
      const d = new Date(iso);
      return d.toLocaleString("ja-JP", {
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
      });
    } catch {
      return iso;
    }
  }

  // ---------- ページ種別の判定 ----------

  function detectPageInfo() {
    const path = location.pathname;

    let m = path.match(/^\/projects\/(\d+)/);
    if (m) return { type: "project", id: m[1] };

    m = path.match(/^\/studios\/(\d+)/);
    if (m) return { type: "studio", id: m[1] };

    return null;
  }

  function pageUrlForComment() {
    const { type, id } = STATE.pageInfo;
    return type === "project"
      ? `https://scratch.mit.edu/projects/${id}/`
      : `https://scratch.mit.edu/studios/${id}/comments/`;
  }

  async function resolveProjectUsername(projectId) {
    try {
      const res = await fetch(`https://api.scratch.mit.edu/projects/${projectId}`);
      if (res.ok) {
        const data = await res.json();
        if (data?.author?.username) return data.author.username;
      }
    } catch (e) {
      log("APIからのユーザー名解決に失敗:", e);
    }

    const authorLink = document.querySelector('a[href^="/users/"]');
    if (authorLink) {
      const m = authorLink.getAttribute("href")?.match(/\/users\/([^/]+)/);
      if (m) return m[1];
    }

    return null;
  }

  // ---------- コメント取得 ----------

  async function fetchProjectComments(username, projectId) {
    const url = `https://api.scratch.mit.edu/users/${encodeURIComponent(
      username
    )}/projects/${projectId}/comments?limit=20&offset=0`;
    const res = await fetch(url);
    if (!res.ok) throw new Error(`コメント取得失敗 (HTTP ${res.status})`);
    return res.json();
  }

  async function fetchStudioComments(studioId) {
    const url = `https://api.scratch.mit.edu/studios/${studioId}/comments?limit=20&offset=0`;
    const res = await fetch(url);
    if (!res.ok) throw new Error(`コメント取得失敗 (HTTP ${res.status})`);
    return res.json();
  }

  async function fetchLatestComments() {
    const { type, id } = STATE.pageInfo;
    if (type === "project") {
      if (!STATE.pageInfo.username) {
        STATE.pageInfo.username = await resolveProjectUsername(id);
      }
      if (!STATE.pageInfo.username) {
        throw new Error("プロジェクト作者のユーザー名を特定できませんでした");
      }
      return fetchProjectComments(STATE.pageInfo.username, id);
    } else {
      return fetchStudioComments(id);
    }
  }

  // ---------- コメント欄(Reactの実DOM)を探す ----------
  //
  // 優先順位:
  //  1. 既知のクラス名(.comments-list 等) — プロジェクトページで確認済み
  //  2. 「投稿する」ボタン(コメント投稿フォームの一部)を起点に、
  //     確実に隣接している本物のコメント一覧を探す — スタジオの
  //     「コメント」タブなど、クラス名が異なるページでも機能する
  //  3. 見出しテキスト("コメント"完全一致)を起点に同様の探索を行う
  //
  // 過去の失敗: 見出しを含む広い範囲を querySelectorAll で大雑把に
  // 探すと、たまたまユーザーリンクを含む別の要素(サイドバー等)を
  // 誤って拾ってしまうことがあった。そのため、いずれの方法も
  // 「直接の子要素が複数、それぞれユーザーリンクを持つ」という
  // 形状を厳密に確認する looksLikeCommentsList() を使う。

  function looksLikeCommentsList(el) {
    if (!el || !el.children || el.children.length === 0) return false;
    let matchingChildren = 0;
    for (const child of el.children) {
      if (child.querySelector('a[href*="/users/"]')) matchingChildren++;
    }
    return matchingChildren >= 1;
  }

  let cachedListEl = null;

  function findCommentsListEl() {
    if (
      cachedListEl &&
      document.documentElement.contains(cachedListEl) &&
      looksLikeCommentsList(cachedListEl)
    ) {
      return cachedListEl;
    }

    for (const sel of COMMENT_LIST_SELECTORS) {
      const el = document.querySelector(sel);
      if (el && looksLikeCommentsList(el)) {
        cachedListEl = el;
        return el;
      }
    }

    const found = findCommentsListByComposeAnchor() || findCommentsListElByHeading();
    cachedListEl = found || null;
    return found;
  }

  // 「投稿する」ボタン(コメント投稿フォームの送信ボタン)を起点に、
  // 祖先をたどりながら「次の兄弟要素」がコメント一覧らしいかを確認する。
  // ボタンの文言はScratchの標準的な日本語UIテキストを使用。
  function findCommentsListByComposeAnchor() {
    const POST_BUTTON_TEXTS = ["投稿する", "post"];
    const buttons = document.querySelectorAll("button");
    let postButton = null;
    for (const b of buttons) {
      const t = (b.textContent || "").trim().toLowerCase();
      if (POST_BUTTON_TEXTS.includes(t)) {
        postButton = b;
        break;
      }
    }
    if (!postButton) return null;

    let node = postButton;
    for (let i = 0; i < 8 && node; i++) {
      const sibling = node.nextElementSibling;
      if (sibling && looksLikeCommentsList(sibling)) {
        return sibling;
      }
      node = node.parentElement;
    }
    return null;
  }

  // クラス名がビルド時にハッシュ化されて変わっている場合の最終フォールバック。
  // 「コメント」という見出し(完全一致)の近くから、同様に兄弟要素を確認する。
  function findCommentsListElByHeading() {
    const headings = document.querySelectorAll("h1, h2, h3, h4, h5, h6");
    for (const h of headings) {
      const text = (h.textContent || "").trim();
      if (!/^comments$|^コメント$/i.test(text)) continue;

      let node = h;
      for (let i = 0; i < 6 && node; i++) {
        const sibling = node.nextElementSibling;
        if (sibling && looksLikeCommentsList(sibling)) {
          return sibling;
        }
        node = node.parentElement;
      }
    }
    return null;
  }

  function buildCommentCardEl(comment) {
    const card = document.createElement("div");
    card.className = INLINE_CARD_CLASS;
    card.dataset.scCommentId = String(comment.id);

    const avatar = comment.author?.image || "https://uploads.scratch.mit.edu/get_image/user/0_60x60.png";
    const username = comment.author?.username || "unknown";
    const content = comment.content || "";
    const datetime = comment.datetime_created || "";

    card.innerHTML = `
      <img class="sc-auto-refresh-avatar" src="${escapeHtml(avatar)}" alt="${escapeHtml(username)}" />
      <div class="sc-auto-refresh-body">
        <div class="sc-auto-refresh-meta">
          <a href="https://scratch.mit.edu/users/${encodeURIComponent(username)}/" target="_blank" rel="noopener" class="sc-auto-refresh-username">${escapeHtml(username)}</a>
          <span class="sc-auto-refresh-time">${escapeHtml(formatDateTime(datetime))}</span>
          <span class="sc-auto-refresh-new-tag">NEW</span>
        </div>
        <div class="sc-auto-refresh-content">${escapeHtml(content)}</div>
      </div>
    `;
    return card;
  }

  // .comments-list の「内側の先頭」にカードを直接差し込む。
  // 外側のページレイアウト(グリッド/フレックスの列構成)には影響しない。
  // すでに表示中のカードが消えていないかも毎回確認し、消えていれば
  // 再挿入する(自己修復)。差分が無ければ何もしない(低コスト)。
  function syncInlineComments() {
    const listEl = findCommentsListEl();
    if (!listEl) {
      if (STATE.commentsListFound !== false) {
        log("コメント欄の要素が見つかりません。");
      }
      STATE.commentsListFound = false;
      return false;
    }
    STATE.commentsListFound = true;

    if (STATE.insertedComments.length === 0) return true;

    const currentCards = Array.from(listEl.children).filter((el) =>
      el.classList.contains(INLINE_CARD_CLASS)
    );

    const alreadyInSync =
      currentCards.length === STATE.insertedComments.length &&
      currentCards.every(
        (el, idx) => el.dataset.scCommentId === String(STATE.insertedComments[idx].id)
      ) &&
      listEl.firstElementChild === currentCards[0];

    if (alreadyInSync) return true;

    log(
      `カードを同期します(現在DOM上: ${currentCards.length}件 / 表示すべき: ${STATE.insertedComments.length}件)`,
      listEl
    );

    // 順序がズレている、または一部/全部が消えている場合は、
    // 一旦すべて取り除いてから正しい順番で先頭に入れ直す。
    currentCards.forEach((el) => el.remove());
    const anchor = listEl.firstChild; // 本来の(Scratch側の)先頭コメント
    STATE.insertedComments.forEach((comment) => {
      const card = buildCommentCardEl(comment);
      listEl.insertBefore(card, anchor);
    });

    log(`コメント欄に ${STATE.insertedComments.length} 件のカードを同期しました。`);
    return true;
  }

  function addNewComments(newComments) {
    // APIは新しい順で返る前提。先頭に追加して上限を超えたら古いものを捨てる。
    STATE.insertedComments = [...newComments, ...STATE.insertedComments].slice(
      0,
      MAX_INLINE_ITEMS
    );
  }

  // ---------- UI: フローティングバッジ(ステータス表示・フォールバック通知) ----------

  let rootEl = null;

  function ensureRoot() {
    if (rootEl && document.documentElement.contains(rootEl)) return rootEl;
    rootEl = document.createElement("div");
    rootEl.id = "sc-auto-refresh-root";
    document.documentElement.appendChild(rootEl);
    renderRoot();
    return rootEl;
  }

  function renderRoot() {
    if (!rootEl) return;

    const statusLine = STATE.lastError
      ? `⚠️ ${escapeHtml(STATE.lastError)}`
      : STATE.settings.enabled
      ? `${STATE.settings.intervalSec}秒ごとに監視中`
      : "監視は停止中です";

    const detectLine = STATE.commentsListFound
      ? "コメント欄: 検出済み(その場所に反映されます)"
      : "コメント欄: 未検出(通知のみ)";

    const lastCheckedLine = STATE.lastCheckedAt
      ? `最終チェック: ${escapeHtml(formatDateTime(STATE.lastCheckedAt))} / 取得 ${STATE.lastFetchCount ?? "-"}件`
      : "まだチェックしていません";

    rootEl.innerHTML = `
      <div class="sc-auto-refresh-badge" id="sc-auto-refresh-badge">
        <span class="sc-auto-refresh-badge-dot"></span>
        <span class="sc-auto-refresh-badge-text">コメント監視中</span>
      </div>
      <div class="sc-auto-refresh-statusbar">
        <a class="sc-auto-refresh-open-link" href="${escapeHtml(pageUrlForComment())}" target="_blank" rel="noopener">コメント欄を開く ↗</a>
        <span>${statusLine}</span>
        <span>${detectLine}</span>
        <span>${lastCheckedLine}</span>
      </div>
    `;

    const badge = rootEl.querySelector("#sc-auto-refresh-badge");
    badge.addEventListener("click", () => {
      const list = findCommentsListEl();
      if (list) list.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  }

  // ---------- メインループ ----------

  async function checkForNewComments({ isFirstRun = false } = {}) {
    if (!STATE.settings.enabled) return;

    let comments;
    try {
      comments = await fetchLatestComments();
      STATE.lastError = null;
    } catch (e) {
      STATE.lastError = e.message;
      STATE.lastCheckedAt = new Date().toISOString();
      log("取得エラー:", e.message);
      renderRoot();
      return;
    }

    STATE.lastCheckedAt = new Date().toISOString();
    STATE.lastFetchCount = Array.isArray(comments) ? comments.length : null;

    if (!Array.isArray(comments)) {
      renderRoot();
      return;
    }

    if (isFirstRun) {
      comments.forEach((c) => STATE.knownCommentIds.add(c.id));
      STATE.initialized = true;
      log(`初期化完了。既存コメント ${comments.length} 件を記録しました。`);
      renderRoot();
      return;
    }

    const newOnes = comments.filter((c) => !STATE.knownCommentIds.has(c.id));
    log(`取得 ${comments.length} 件中、既知でないもの(新着) ${newOnes.length} 件。`);
    if (newOnes.length === 0) {
      renderRoot();
      return;
    }

    newOnes.forEach((c) => STATE.knownCommentIds.add(c.id));
    addNewComments(newOnes);
    syncInlineComments();

    log(`新着コメント ${newOnes.length} 件を検出し、コメント欄に反映しました。`);
    renderRoot();
  }

  function startPolling() {
    stopPolling();
    if (!STATE.settings.enabled) return;
    const ms = Math.max(5, STATE.settings.intervalSec) * 1000;
    STATE.timerId = setInterval(() => checkForNewComments(), ms);
    log(`ポーリング開始 (${STATE.settings.intervalSec}秒間隔)`);
  }

  function stopPolling() {
    if (STATE.timerId) {
      clearInterval(STATE.timerId);
      STATE.timerId = null;
    }
  }

  // ---------- 設定の読み込み・反映 ----------

  function loadSettings() {
    return new Promise((resolve) => {
      if (!chrome?.storage?.sync) {
        resolve({ ...DEFAULT_SETTINGS });
        return;
      }
      chrome.storage.sync.get(DEFAULT_SETTINGS, (items) => {
        resolve({ ...DEFAULT_SETTINGS, ...items });
      });
    });
  }

  function watchSettingsChanges() {
    if (!chrome?.storage?.onChanged) return;
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "sync") return;
      let changed = false;
      if (changes.enabled) {
        STATE.settings.enabled = changes.enabled.newValue;
        changed = true;
      }
      if (changes.intervalSec) {
        STATE.settings.intervalSec = changes.intervalSec.newValue;
        changed = true;
      }
      if (changed) {
        log("設定が更新されました:", STATE.settings);
        if (STATE.settings.enabled) {
          startPolling();
        } else {
          stopPolling();
        }
        renderRoot();
      }
    });
  }

  // ---------- 初期化 ----------

  let initializedOnce = false;

  async function init() {
    const pageInfo = detectPageInfo();
    if (!pageInfo) return;

    STATE.pageInfo = pageInfo;

    if (!initializedOnce) {
      STATE.settings = await loadSettings();
      watchSettingsChanges();
      initializedOnce = true;
    }

    ensureRoot();
    syncInlineComments(); // コメント欄の検出状況を初期反映

    await checkForNewComments({ isFirstRun: true });
    startPolling();

    window.addEventListener("beforeunload", stopPolling);
  }

  // ---------- SPA描画・遷移の監視(軽量版) ----------
  //
  // ページ全体を監視する MutationObserver は、ScratchのページがReactで
  // 頻繁にDOM更新を行うため、監視→DOM操作→再度検知...という負荷の高い
  // ループになり、ページの動作を妨げることがあったため使用しない。
  // 代わりに setInterval による軽量な定期チェックで:
  //   1. URLの変化(SPA内遷移)を検知して再初期化
  //   2. 挿入したカードがまだ正しい位置にあるかを確認し、自己修復する
  // を行う。どちらも数十個以下のDOM要素を比較するだけの軽い処理。

  let lastPath = location.pathname;

  function watchTick() {
    if (location.pathname !== lastPath) {
      lastPath = location.pathname;
      stopPolling();
      STATE.knownCommentIds.clear();
      STATE.insertedComments = [];
      STATE.initialized = false;
      STATE.lastError = null;
      STATE.commentsListFound = false;
      cachedListEl = null;
      init();
      return;
    }

    syncInlineComments();
  }

  setInterval(watchTick, WATCH_INTERVAL_MS);

  // ---------- テスト用: ポップアップからのダミーコメント挿入 ----------
  // 実際の新着コメントを待たずに、反映処理だけを検証できるようにする。

  if (chrome?.runtime?.onMessage) {
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      if (message?.type !== "SC_AUTO_REFRESH_TEST_INSERT") return;

      if (!STATE.pageInfo) {
        sendResponse({ ok: false, reason: "対象ページとして認識されていません" });
        return;
      }

      const dummy = {
        id: `test-${Date.now()}`,
        author: { username: "テストユーザー", image: "" },
        content: `これはテスト用のダミーコメントです(${new Date().toLocaleTimeString("ja-JP")})`,
        datetime_created: new Date().toISOString(),
      };

      addNewComments([dummy]);
      const synced = syncInlineComments();
      renderRoot();

      log("テスト用ダミーコメントを挿入しました。同期結果:", synced);
      sendResponse({
        ok: synced,
        reason: synced ? null : "コメント欄の要素が見つかりませんでした",
      });
    });
  }

  init();
})();
