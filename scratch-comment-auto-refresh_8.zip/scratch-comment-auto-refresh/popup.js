const DEFAULT_SETTINGS = {
  enabled: true,
  intervalSec: 20,
};

const enabledToggle = document.getElementById("enabledToggle");
const intervalInput = document.getElementById("intervalInput");
const statusText = document.getElementById("statusText");

function showStatus(message) {
  statusText.textContent = message;
  clearTimeout(showStatus._t);
  showStatus._t = setTimeout(() => {
    statusText.textContent = "";
  }, 1500);
}

function loadSettings() {
  chrome.storage.sync.get(DEFAULT_SETTINGS, (items) => {
    enabledToggle.checked = !!items.enabled;
    intervalInput.value = items.intervalSec ?? DEFAULT_SETTINGS.intervalSec;
  });
}

function saveSettings() {
  const enabled = enabledToggle.checked;
  let intervalSec = parseInt(intervalInput.value, 10);
  if (Number.isNaN(intervalSec)) intervalSec = DEFAULT_SETTINGS.intervalSec;
  intervalSec = Math.min(600, Math.max(5, intervalSec));
  intervalInput.value = intervalSec;

  chrome.storage.sync.set({ enabled, intervalSec }, () => {
    showStatus("保存しました");
  });
}

enabledToggle.addEventListener("change", saveSettings);
intervalInput.addEventListener("change", saveSettings);

const testInsertBtn = document.getElementById("testInsertBtn");
testInsertBtn.addEventListener("click", () => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs[0];
    if (!tab?.id) {
      showStatus("対象タブが見つかりません");
      return;
    }
    chrome.tabs.sendMessage(tab.id, { type: "SC_AUTO_REFRESH_TEST_INSERT" }, (response) => {
      if (chrome.runtime.lastError) {
        showStatus("Scratchのページで開いてください");
        return;
      }
      if (response?.ok) {
        showStatus("テスト用コメントを表示しました");
      } else {
        showStatus(response?.reason || "反映に失敗しました");
      }
    });
  });
});

loadSettings();
